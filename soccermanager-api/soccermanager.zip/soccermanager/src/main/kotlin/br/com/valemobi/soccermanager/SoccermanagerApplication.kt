package br.com.valemobi.soccermanager

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class SoccermanagerApplication

fun main(args: Array<String>) {
	runApplication<SoccermanagerApplication>(*args)
}
